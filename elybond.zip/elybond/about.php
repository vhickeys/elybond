<?php
$title = "About";
include_once("components/head.php");
// include_once("components/topbar.php");
include_once("components/header.php");
// include_once("components/slider.php");
?>

<section id="page-title" style="background-image: url(&quot;images/elybond/about.jpg&quot;); background-position: 0 -500px; padding: 200px 0px; background-size: cover;">
    <div class="container clearfix">
        <div class="row">
            <div class="col-md-7">
                <h1 class="text-white">About</h1>
                <span class="text-white">We undertake interiors and exteriors of buildings living, commercial, churches, schools, auditorium etc. our expertise and timely delivery on this had earned us high reputation from construction companies, architects in urban and rural developments as a single source of finishing products and services.</span>
            </div>
        </div>
    </div>
</section>

<section id="content">
    <div class="container">
        <div class="my-5">
            <div class="row">
                <div class="col-md-7">
                    <div class="heading-block">
                        <span class="before-heading color">About Us</span>
                        <h3>Elybond Marbles</h3>
                    </div>
                    <div class="">
                        <p>We are Elybond Int’l Ltd, a company incorporated on the 3rd of November 1997 as an entity designated to carry on the business of manufacturing, processing, installation, distribution single handedly and in partnership with capable hands to facilitate the conversion of natural, artificial stones business for interiors and exteriors decorations
                            <br><br>
                            This ideology metamorphosed \from the initial establishment of sourcing, selling and installations of rubber or plastic tile for flooring, walls and other decoration purposes.
                            In abid to translate into a mega industrial hub of natural stones source that include as, GRANITES QUARTZ, ONYX ITRAVERTINE, PORCELAIN, CERAMICS, tiles and slabs.
                        </p>
                        <a href="#" class="social-icon inline-block si-small si-light si-rounded si-facebook">
                            <i class="icon-facebook"></i>
                            <i class="icon-facebook"></i>
                        </a>
                        <a href="#" class="social-icon inline-block si-small si-light si-rounded si-twitter">
                            <i class="icon-twitter"></i>
                            <i class="icon-twitter"></i>
                        </a>
                        <a href="#" class="social-icon inline-block si-small si-light si-rounded si-gplus">
                            <i class="icon-mail"></i>
                            <i class="icon-mail"></i>
                        </a>
                    </div>
                </div>

                <div class="col-md-5">
                    <div class="img-fluid">
                        <img src="images/elybond/about2.jpg" alt="">
                    </div>
                </div>
            </div>
        </div>

        <div class="fancy-title title-border">
            <h3>We also introduced heavy duty machines for:</h3>
        </div>
        <div class="row justify-content-center col-mb-50 mb-0">
            <div class="col-sm-6 col-lg-4">
                <div class="feature-box fbox-center fbox-bg fbox-light fbox-effect">
                    <div class="fbox-icon">
                        <a href="#"><i class="i-alt">1</i></a>
                    </div>
                    <div class="fbox-content">
                        <h3><span class="subtitle">Cutting of tiles, slabs, countertops- kitchen tops, altar, pulpits, sink hole and such other demands as may be called on. </span></h3>
                    </div>
                </div>
            </div>
            <div class="col-sm-6 col-lg-4">
                <div class="feature-box fbox-center fbox-bg fbox-border fbox-effect">
                    <div class="fbox-icon">
                        <a href="#"><i>2</i></a>
                    </div>
                    <div class="fbox-content">
                        <h3><span class="subtitle">Filling, buffing and finishing of rough cut materials.</span></h3>
                    </div>
                </div>
            </div>
            <div class="col-sm-6 col-lg-4">
                <div class="feature-box fbox-center fbox-bg fbox-outline fbox-dark fbox-effect">
                    <div class="fbox-icon">
                        <a href="#"><i class="i-alt">3</i></a>
                    </div>
                    <div class="fbox-content">
                        <h3><span class="subtitle">Cladding stones, floor tiles of different sizes, brands either customized or conventional.</span></h3>
                    </div>
                </div>
            </div>
        </div>

        <div class="row row2">
            <div class="col-md-12">
                <p>
                    We source materials initially from other world renowned factories from Portugal, Spain, china, India, Italy and
                    other countries from middle East, due to our high capital base that skipped from a 0 -seven(7), l digit to twelve digit(12) and still more, we were able to join forces with giants in sourcing exortic stones and most cost effective products from different hands of professional.
                    Upon the above status,on the plight for quick, services and ease to processing of stones to different shapes, sizes and patterns not excluding the inscription on hard stones as in tombstones, inauguration of houses, halls etc.</p>
                <p>
                    Furthermore we undertake interiors and exteriors of buildings living, commercial, churches, schools, auditorium etc. our expertise and timely delivery on this had earned us high reputation from construction companies, architects in urban and rural developments as a single source of finishing products and services. <br><br>
                    Our team of professionals in consulting, installation, technical wizards have worked seamlessly in keeping our work base as solid brand geared with timely attendance to issues or challenges that may naturally arise in the course of services. Our team are highly equipped for standard performance in delivery and product specification according to our clients demand. <br>
                    Our continued growth amidst the rough and struck business environment had pushed us to develop block processing that can lead to more product availability e.g. tiles, slabs and other stones for different application needs all at affordable rates.
                    Finally our target is to continued emerging as the single source of all stones and building materials as the need comes. Hoping to partner with you in services as the demands will be.
                </p>
            </div>
        </div>
    </div>
</section>


<?php
include_once("components/footer.php");
?>