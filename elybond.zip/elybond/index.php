<?php
$title = "Homepage";
include_once("components/head.php");
// include_once("components/topbar.php");
include_once("components/header.php");
include_once("components/slider.php");
?>

<section id="content">
    <div class="content-wrap">
        <div class="promo promo-light promo-full promo-uppercase p-5 bottommargin-lg header-stick">
            <div class="container clearfix">
                <div class="row align-items-center">
                    <div class="col-12 col-lg">
                        <span class="text-lowercase"> Our target is to continued emerging as the single source of all
                            stones and building
                            materials as the need comes. Hoping to partner with you in services as the demands will
                            be.</span>
                    </div>
                    <div class="col-12 col-lg-auto mt-4 mt-lg-0">
                        <a href="about.php" class="button button-large button-circle button-black m-0">Learn More</a>
                    </div>
                </div>
            </div>
        </div>
        <div class="container clearfix">
            <div class="row justify-content-center col-mb-50">
                <div class="col-sm-6 col-lg-4">
                    <div class="feature-box media-box">
                        <div class="fbox-media">
                            <img class="rounded" src="images/elybond/5.jpg" alt="Why choose Us elybond?">
                        </div>
                        <div class="fbox-content px-0">
                            <h3>Cutting</h3>
                            <p> Cutting of tiles, slabs, countertops- kitchen tops, altar, pulpits, sink hole and such other demands as may be called on.
                            </p>
                        </div>
                    </div>
                </div>
                <div class="col-sm-6 col-lg-4">
                    <div class="feature-box media-box">
                        <div class="fbox-media">
                            <img class="rounded" src="images/elybond/4.jpg" alt="elybond filling">
                        </div>
                        <div class="fbox-content px-0">
                            <h3>Filling</h3>
                            <p> Filling, buffing and finishing of rough cut materials.</p>
                        </div>
                    </div>
                </div>
                <div class="col-sm-6 col-lg-4">
                    <div class="feature-box media-box">
                        <div class="fbox-media">
                            <img class="rounded" src="images/elybond/7.jpg" alt="Elybond Cladding">
                        </div>
                        <div class="fbox-content px-0">
                            <h3>Cladding</h3>
                            <p>Cladding stones, floor tiles of different sizes, brands either customized or conventional.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Portfolio -->

        <section class="elyPortfolio">
            <div class="container clearfix">
                <div class="heading-block center">
                    <h3>Portfolio</h3>
                </div>
                <div id="portfolio" class="portfolio row grid-container gutter-30 has-init-isotope" data-layout="fitRows" style="position: relative; height: 3576.75px;">
                    <article class="portfolio-item col-md-4 col-sm-6 col-12 pf-media pf-icons" style="position: absolute; left: 0%; top: 0px;">
                        <div class="grid-inner">
                            <div class="portfolio-image">
                                <a href="#">
                                    <img src="images/elybond/1.jpg" alt="Elybond Portfolio 1">
                                </a>
                                <div class="bg-overlay">
                                    <div class="bg-overlay-content dark animated fadeOut" data-hover-animate="fadeIn" style="animation-duration: 600ms;">
                                        <a href="images/elybond/1.jpg" class="overlay-trigger-icon bg-light text-dark animated fadeOutUpSmall" data-hover-animate="fadeInDownSmall" data-hover-animate-out="fadeOutUpSmall" data-hover-speed="350" data-lightbox="image" title="Image" style="animation-duration: 350ms;"><i class="icon-line-plus"></i></a>
                                    </div>
                                    <div class="bg-overlay-bg dark animated fadeOut" data-hover-animate="fadeIn" style="animation-duration: 600ms;"></div>
                                </div>
                            </div>
                            <div class="portfolio-desc">
                                <h3>Granite</h3>
                            </div>
                        </div>
                    </article>
                    <article class="portfolio-item col-md-4 col-sm-6 col-12 pf-illustrations" style="position: absolute; left: 0%; top: 387.25px;">
                        <div class="grid-inner">
                            <div class="portfolio-image">
                                <a href="#">
                                    <img src="images/elybond/4.jpg" alt="Elybond Portfolio 2">
                                </a>
                                <div class="bg-overlay">
                                    <div class="bg-overlay-content dark animated fadeOut" data-hover-animate="fadeIn" style="animation-duration: 600ms;">
                                        <a href="images/elybond/4.jpg" class="overlay-trigger-icon bg-light text-dark animated fadeOutUpSmall" data-hover-animate="fadeInDownSmall" data-hover-animate-out="fadeOutUpSmall" data-hover-speed="350" data-lightbox="image" title="Image" style="animation-duration: 350ms;"><i class="icon-line-plus"></i></a>
                                    </div>
                                    <div class="bg-overlay-bg dark animated fadeOut" data-hover-animate="fadeIn" style="animation-duration: 600ms;"></div>
                                </div>
                            </div>
                            <div class="portfolio-desc">
                                <h3>Tiles</h3>
                            </div>
                        </div>
                    </article>
                    <article class="portfolio-item col-md-4 col-sm-6 col-12 pf-graphics pf-uielements" style="position: absolute; left: 0%; top: 774.5px;">
                        <div class="grid-inner">
                            <div class="portfolio-image">
                                <a href="#">
                                    <img src="images/elybond/3.jpg" alt="Elybond Portfolio 3">
                                </a>
                                <div class="bg-overlay">
                                    <div class="bg-overlay-content dark animated fadeOut" data-hover-animate="fadeIn" style="animation-duration: 600ms;">
                                        <a href="images/elybond/3.jpg" class="overlay-trigger-icon bg-light text-dark animated fadeOutUpSmall" data-hover-animate="fadeInDownSmall" data-hover-animate-out="fadeOutUpSmall" data-hover-speed="350" data-lightbox="image" title="Image" style="animation-duration: 350ms;"><i class="icon-line-plus"></i></a>
                                    </div>
                                    <div class="bg-overlay-bg dark animated fadeOut" data-hover-animate="fadeIn" style="animation-duration: 600ms;"></div>
                                </div>
                            </div>
                            <div class="portfolio-desc">
                                <h3>Ceramics</h3>
                            </div>
                        </div>
                    </article>
                    <article class="portfolio-item col-md-4 col-sm-6 col-12 pf-media pf-icons" style="position: absolute; left: 0%; top: 0px;">
                        <div class="grid-inner">
                            <div class="portfolio-image">
                                <a href="#">
                                    <img src="images/elybond/5.jpg" alt="Elybond Portfolio 1">
                                </a>
                                <div class="bg-overlay">
                                    <div class="bg-overlay-content dark animated fadeOut" data-hover-animate="fadeIn" style="animation-duration: 600ms;">
                                        <a href="images/elybond/5.jpg" class="overlay-trigger-icon bg-light text-dark animated fadeOutUpSmall" data-hover-animate="fadeInDownSmall" data-hover-animate-out="fadeOutUpSmall" data-hover-speed="350" data-lightbox="image" title="Image" style="animation-duration: 350ms;"><i class="icon-line-plus"></i></a>
                                    </div>
                                    <div class="bg-overlay-bg dark animated fadeOut" data-hover-animate="fadeIn" style="animation-duration: 600ms;"></div>
                                </div>
                            </div>
                            <div class="portfolio-desc">
                                <h3>Tiles</h3>
                            </div>
                        </div>
                    </article>
                    <article class="portfolio-item col-md-4 col-sm-6 col-12 pf-illustrations" style="position: absolute; left: 0%; top: 387.25px;">
                        <div class="grid-inner">
                            <div class="portfolio-image">
                                <a href="#">
                                    <img src="images/elybond/1.jpg" alt="Elybond Portfolio 2">
                                </a>
                                <div class="bg-overlay">
                                    <div class="bg-overlay-content dark animated fadeOut" data-hover-animate="fadeIn" style="animation-duration: 600ms;">
                                        <a href="images/elybond/1.jpg" class="overlay-trigger-icon bg-light text-dark animated fadeOutUpSmall" data-hover-animate="fadeInDownSmall" data-hover-animate-out="fadeOutUpSmall" data-hover-speed="350" data-lightbox="image" title="Image" style="animation-duration: 350ms;"><i class="icon-line-plus"></i></a>
                                    </div>
                                    <div class="bg-overlay-bg dark animated fadeOut" data-hover-animate="fadeIn" style="animation-duration: 600ms;"></div>
                                </div>
                            </div>
                            <div class="portfolio-desc">
                                <h3>Granite</h3>
                            </div>
                        </div>
                    </article>
                    <article class="portfolio-item col-md-4 col-sm-6 col-12 pf-graphics pf-uielements" style="position: absolute; left: 0%; top: 774.5px;">
                        <div class="grid-inner">
                            <div class="portfolio-image">
                                <a href="#">
                                    <img src="images/elybond/7.jpg" alt="Elybond Portfolio 3">
                                </a>
                                <div class="bg-overlay">
                                    <div class="bg-overlay-content dark animated fadeOut" data-hover-animate="fadeIn" style="animation-duration: 600ms;">
                                        <a href="images/elybond/7.jpg" class="overlay-trigger-icon bg-light text-dark animated fadeOutUpSmall" data-hover-animate="fadeInDownSmall" data-hover-animate-out="fadeOutUpSmall" data-hover-speed="350" data-lightbox="image" title="Image" style="animation-duration: 350ms;"><i class="icon-line-plus"></i></a>
                                    </div>
                                    <div class="bg-overlay-bg dark animated fadeOut" data-hover-animate="fadeIn" style="animation-duration: 600ms;"></div>
                                </div>
                            </div>
                            <div class="portfolio-desc">
                                <h3>Filling</h3>
                            </div>
                        </div>
                    </article>
                </div>
            </div>
        </section>

        <!-- Portfolio Ends -->

        <!-- Parallax -->

        <div class="section mb-5 parallax dark mb-0 skrollable skrollable-before" style="background-image: url(&quot;images/elybond/parallax.jpg&quot;); padding: 100px 0px; background-position: 0px 300px; background-size: cover;" data-bottom-top="background-position:0px 300px;" data-top-bottom="background-position:0px -300px;">
            <div class="heading-block center">
                <h3>Who are We?</h3>
            </div>
            <p class="text-center px-4">We are an entity designated to carry on the business of manufacturing, processing, installation, <br> distribution single handedly and in partnership with capable hands to facilitate the conversion of natural, artificial stones business for interiors and exteriors decorations.</p>
        </div>

        <!-- Good Hands -->

        <div class="section bg-transparent mt-0 p-0 footer-stick">
            <div class="container clearfix">
                <div class="row my-5">
                    <div class="col-lg-7">
                        <img src="images/elybond/1.jpg" alt="elybond">
                    </div>
                    <div class="col-lg-5 topmargin-sm">
                        <div class="heading-block border-bottom-0">
                            <h2>You're in Good Hands.</h2>
                            <span class="ls1">Three Points that define Our Reliability.</span>
                        </div>
                        <ul class="iconlist iconlist-large iconlist-color">
                            <li><i class="icon-ok"></i> Cutting of tiles, slabs, countertops- kitchen tops, altar,
                                pulpits, sink hole and such other demands as may be called on.</li>
                            <li><i class="icon-ok"></i> Filling, buffing and finishing of rough cut materials.</li>
                            <li><i class="icon-ok"></i> Cladding stones, floor tiles of different sizes, brands either
                                customized or conventional.</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>

        <!-- Good Hands Ends -->

    </div>
</section>

<?php
include_once("components/footer.php");
?>