<?php
$title = "Portfolio";
include_once("components/head.php");
// include_once("components/topbar.php");
include_once("components/header.php");
?>

<section id="page-title" style="background-image: url(&quot;images/elybond/8.jpg&quot;); background-position: 0 -500px; padding: 200px 0px; background-size: cover;">
    <div class="container clearfix">
        <h1 class="text-white">Portfolio</h1>
        <!-- <span>Showcase of Our Awesome Works in 3 Columns</span> -->
    </div>
</section>

<section id="content">
    <div class="content-wrap">
        <div class="container clearfix">
            <div id="portfolio" class="portfolio row grid-container gutter-30 has-init-isotope" data-layout="fitRows" style="position: relative; height: 3576.75px;">
                <article class="portfolio-item col-md-4 col-sm-6 col-12 pf-media pf-icons" style="position: absolute; left: 0%; top: 0px;">
                    <div class="grid-inner">
                        <div class="portfolio-image">
                            <a href="#">
                                <img src="images/elybond/1.jpg" alt="Elybond Portfolio 1">
                            </a>
                            <div class="bg-overlay">
                                <div class="bg-overlay-content dark animated fadeOut" data-hover-animate="fadeIn" style="animation-duration: 600ms;">
                                    <a href="images/elybond/1.jpg" class="overlay-trigger-icon bg-light text-dark animated fadeOutUpSmall" data-hover-animate="fadeInDownSmall" data-hover-animate-out="fadeOutUpSmall" data-hover-speed="350" data-lightbox="image" title="Image" style="animation-duration: 350ms;"><i class="icon-line-plus"></i></a>
                                </div>
                                <div class="bg-overlay-bg dark animated fadeOut" data-hover-animate="fadeIn" style="animation-duration: 600ms;"></div>
                            </div>
                        </div>
                        <div class="portfolio-desc">
                            <h3>Granite</h3>
                        </div>
                    </div>
                </article>
                <article class="portfolio-item col-md-4 col-sm-6 col-12 pf-illustrations" style="position: absolute; left: 0%; top: 387.25px;">
                    <div class="grid-inner">
                        <div class="portfolio-image">
                            <a href="#">
                                <img src="images/elybond/4.jpg" alt="Elybond Portfolio 2">
                            </a>
                            <div class="bg-overlay">
                                <div class="bg-overlay-content dark animated fadeOut" data-hover-animate="fadeIn" style="animation-duration: 600ms;">
                                    <a href="images/elybond/4.jpg" class="overlay-trigger-icon bg-light text-dark animated fadeOutUpSmall" data-hover-animate="fadeInDownSmall" data-hover-animate-out="fadeOutUpSmall" data-hover-speed="350" data-lightbox="image" title="Image" style="animation-duration: 350ms;"><i class="icon-line-plus"></i></a>
                                </div>
                                <div class="bg-overlay-bg dark animated fadeOut" data-hover-animate="fadeIn" style="animation-duration: 600ms;"></div>
                            </div>
                        </div>
                        <div class="portfolio-desc">
                            <h3>Tiles</h3>
                        </div>
                    </div>
                </article>
                <article class="portfolio-item col-md-4 col-sm-6 col-12 pf-graphics pf-uielements" style="position: absolute; left: 0%; top: 774.5px;">
                    <div class="grid-inner">
                        <div class="portfolio-image">
                            <a href="#">
                                <img src="images/elybond/3.jpg" alt="Elybond Portfolio 3">
                            </a>
                            <div class="bg-overlay">
                                <div class="bg-overlay-content dark animated fadeOut" data-hover-animate="fadeIn" style="animation-duration: 600ms;">
                                    <a href="images/elybond/3.jpg" class="overlay-trigger-icon bg-light text-dark animated fadeOutUpSmall" data-hover-animate="fadeInDownSmall" data-hover-animate-out="fadeOutUpSmall" data-hover-speed="350" data-lightbox="image" title="Image" style="animation-duration: 350ms;"><i class="icon-line-plus"></i></a>
                                </div>
                                <div class="bg-overlay-bg dark animated fadeOut" data-hover-animate="fadeIn" style="animation-duration: 600ms;"></div>
                            </div>
                        </div>
                        <div class="portfolio-desc">
                            <h3>Ceramics</h3>
                        </div>
                    </div>
                </article>
                <article class="portfolio-item col-md-4 col-sm-6 col-12 pf-media pf-icons" style="position: absolute; left: 0%; top: 0px;">
                    <div class="grid-inner">
                        <div class="portfolio-image">
                            <a href="#">
                                <img src="images/elybond/5.jpg" alt="Elybond Portfolio 1">
                            </a>
                            <div class="bg-overlay">
                                <div class="bg-overlay-content dark animated fadeOut" data-hover-animate="fadeIn" style="animation-duration: 600ms;">
                                    <a href="images/elybond/5.jpg" class="overlay-trigger-icon bg-light text-dark animated fadeOutUpSmall" data-hover-animate="fadeInDownSmall" data-hover-animate-out="fadeOutUpSmall" data-hover-speed="350" data-lightbox="image" title="Image" style="animation-duration: 350ms;"><i class="icon-line-plus"></i></a>
                                </div>
                                <div class="bg-overlay-bg dark animated fadeOut" data-hover-animate="fadeIn" style="animation-duration: 600ms;"></div>
                            </div>
                        </div>
                        <div class="portfolio-desc">
                            <h3>Tiles</h3>
                        </div>
                    </div>
                </article>
                <article class="portfolio-item col-md-4 col-sm-6 col-12 pf-illustrations" style="position: absolute; left: 0%; top: 387.25px;">
                    <div class="grid-inner">
                        <div class="portfolio-image">
                            <a href="#">
                                <img src="images/elybond/1.jpg" alt="Elybond Portfolio 2">
                            </a>
                            <div class="bg-overlay">
                                <div class="bg-overlay-content dark animated fadeOut" data-hover-animate="fadeIn" style="animation-duration: 600ms;">
                                    <a href="images/elybond/1.jpg" class="overlay-trigger-icon bg-light text-dark animated fadeOutUpSmall" data-hover-animate="fadeInDownSmall" data-hover-animate-out="fadeOutUpSmall" data-hover-speed="350" data-lightbox="image" title="Image" style="animation-duration: 350ms;"><i class="icon-line-plus"></i></a>
                                </div>
                                <div class="bg-overlay-bg dark animated fadeOut" data-hover-animate="fadeIn" style="animation-duration: 600ms;"></div>
                            </div>
                        </div>
                        <div class="portfolio-desc">
                            <h3>Granite</h3>
                        </div>
                    </div>
                </article>
                <article class="portfolio-item col-md-4 col-sm-6 col-12 pf-graphics pf-uielements" style="position: absolute; left: 0%; top: 774.5px;">
                    <div class="grid-inner">
                        <div class="portfolio-image">
                            <a href="#">
                                <img src="images/elybond/7.jpg" alt="Elybond Portfolio 3">
                            </a>
                            <div class="bg-overlay">
                                <div class="bg-overlay-content dark animated fadeOut" data-hover-animate="fadeIn" style="animation-duration: 600ms;">
                                    <a href="images/elybond/7.jpg" class="overlay-trigger-icon bg-light text-dark animated fadeOutUpSmall" data-hover-animate="fadeInDownSmall" data-hover-animate-out="fadeOutUpSmall" data-hover-speed="350" data-lightbox="image" title="Image" style="animation-duration: 350ms;"><i class="icon-line-plus"></i></a>
                                </div>
                                <div class="bg-overlay-bg dark animated fadeOut" data-hover-animate="fadeIn" style="animation-duration: 600ms;"></div>
                            </div>
                        </div>
                        <div class="portfolio-desc">
                            <h3>Filling</h3>
                        </div>
                    </div>
                </article>
            </div>
        </div>
    </div>
</section>

<?php
include_once("components/footer.php");
?>