<html dir="ltr" lang="en-US" class="skrollr skrollr-desktop">

<head>
    <meta http-equiv="content-type" content="text/html;charset=utf-8">

    <meta http-equiv="content-type" content="text/html; charset=utf-8">
    <meta name="author" content="SemiColonWeb">

    <link
        href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700|Roboto:300,400,500,700&amp;display=swap"
        rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="css/bootstrap.css" type="text/css">
    <link rel="stylesheet" href="css/style.css" type="text/css">
    <link rel="stylesheet" href="css/swiper.css" type="text/css">

    <link rel="stylesheet" href="demos/construction/construction.css" type="text/css">

    <link rel="stylesheet" href="css/dark.css" type="text/css">
    <link rel="stylesheet" href="css/font-icons.css" type="text/css">
    <link rel="stylesheet" href="css/animate.css" type="text/css">
    <link rel="stylesheet" href="css/magnific-popup.css" type="text/css">
    <link rel="stylesheet" href="demos/construction/css/fonts.css" type="text/css">
    <link rel="stylesheet" href="css/custom.css" type="text/css">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="css/colors6bbb.css?color=155293" type="text/css">

    <title><?php if(isset($title)) {echo $title . " | Elybond Marbles";} else{ echo "Elybond Marbles";}?></title>

    <!-- My Favicon -->
    <link rel="apple-touch-icon" sizes="180x180" href="images/elybond/favicon_io/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="images/elybond/favicon_io/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="images/elybond/favicon_io/favicon-16x16.png">
    <link rel="manifest" href="images/elybond/favicon_io/site.webmanifest">

    <script src="https://www.googletagmanager.com/gtag/js?id=G-H74KY38NCR"></script>
    <style type="text/css">
    .menu-container>.mega-menu:not(.mega-menu-small) .mega-menu-content {
        top: calc(100% - NaNpx);
    }
    </style>
</head>

<body
    class="stretched has-plugin-easing has-plugin-bootstrap has-plugin-lightbox has-plugin-swiper has-plugin-hoveranimation has-plugin-tabs has-plugin-counter has-plugin-flexslider has-plugin-carousel has-plugin-form quick-contact-form-ready has-plugin-ajaxform has-plugin-subscribeform has-plugin-isotope has-plugin-parallax has-plugin-html5video device-xs">