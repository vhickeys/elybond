<section id="slider" class="slider-element slider-parallax swiper_wrapper min-vh-75 slider-parallax-visible"
    data-loop="true" style="transform: translate3d(0px, 0px, 0px);">
    <div
        class="swiper-container swiper-parent swiper-initialized swiper-horizontal swiper-pointer-events swiper-backface-hidden">
        <div class="swiper-wrapper" id="swiper-wrapper-65364b55841310017" aria-live="off"
            style="cursor: grab; transition-duration: 0ms; transform: translate3d(-360px, 0px, 0px);">
            <div class="swiper-slide swiper-slide-duplicate swiper-slide-prev" data-swiper-slide-index="2" role="group"
                aria-label="3 / 3" style="width: 360px;">
                <div class="container">
                    <div class="slider-caption" style="opacity: 1;">
                        <div>
                            <h2>Premium Constructions</h2>
                            <p class="d-sm-block">You'll be surprised to see the Final Results of your
                                Creation &amp; would crave for more.</p>
                        </div>
                    </div>
                </div>
                <div class="swiper-slide-bg"
                    style="background-image: url('images/elybond/2.jpg'); background-position: center bottom;">
                </div>
            </div>
            <div class="swiper-slide swiper-slide-active" data-swiper-slide-index="0" role="group" aria-label="1 / 3"
                style="width: 360px;">
                <div class="container">
                    <div class="slider-caption" style="transform: translate3d(0px, 0px, 0px); opacity: 1;">
                        <div>
                            <h2>Welcome to Elybond</h2>
                            <p class="d-sm-block">We are Elybond Int’l Ltd, a company incorporated on the 3rd of
                                November 1997 as an entity designated to carry on the business of manufacturing,
                                processing, installation, distribution single handedly and in partnership with capable
                                hands to facilitate the conversion of natural, artificial stones business for interiors
                                and exteriors decorations.
                            </p>
                        </div>
                    </div>
                </div>
                <div class="swiper-slide-bg"
                    style="background-image: url('images/elybond/1.jpg'); background-position: center top;">
                </div>
            </div>
            <div class="swiper-slide swiper-slide-next" data-swiper-slide-index="1" role="group" aria-label="2 / 3"
                style="width: 360px;">
                <div class="container">
                    <div class="slider-caption slider-caption-right" style="opacity: 1;">
                        <div>
                            <h2>Our Ideology</h2>
                            <p class="d-sm-block">This ideology metamorphosed from the initial establishment of
                                sourcing, selling and installations of rubber or plastic tile for flooring, walls and
                                other decoration purposes.</p>
                        </div>
                    </div>
                </div>
                <div class="video-wrap">
                    <video id="slide-video" poster="images/elybond/4.jpg" preload="auto" loop="" autoplay="" muted=""
                        style="width: 853.333px; height: 480px; left: -246.667px; display: none;">
                        <!-- <source src="demos/construction/images/videos/1.webm" type="video/webm">
                        <source src="demos/construction/images/videos/1.mp4" type="video/mp4"> -->
                    </video>
                    <div class="video-overlay" style="background-color: rgba(0,0,0,0.1);"></div>
                    <div class="video-placeholder" style="background-image: url(images/elybond/4.jpg);"></div>
                </div>
            </div>
            <div class="swiper-slide swiper-slide-duplicate-prev" data-swiper-slide-index="2" role="group"
                aria-label="3 / 3" style="width: 360px;">
                <div class="container">
                    <div class="slider-caption" style="opacity: 1;">
                        <div>
                            <h2>Our Goal</h2>
                            <p class="d-sm-block">In a bid to translate into a mega industrial hub of natural
                                stones source that include as, GRANITES QUARTZ, ONYX ITRAVERTINE, PORCELAIN, CERAMICS,
                                tiles and slabs.</p>
                        </div>
                    </div>
                </div>
                <div class="swiper-slide-bg"
                    style="background-image: url('images/elybond/5.jpg'); background-position: center bottom;">
                </div>
            </div>
        </div>
        <div class="slider-arrow-left" tabindex="0" role="button" aria-label="Previous slide"
            aria-controls="swiper-wrapper-65364b55841310017" style="opacity: 1;"><i class="icon-angle-left"></i>
        </div>
        <div class="slider-arrow-right" tabindex="0" role="button" aria-label="Next slide"
            aria-controls="swiper-wrapper-65364b55841310017" style="opacity: 1;"><i class="icon-angle-right"></i>
        </div>
        <span class="swiper-notification" aria-live="assertive" aria-atomic="true"></span>
    </div>
</section>