<footer id="footer" class="dark">
    <div class="container">

        <div class="footer-widgets-wrap">
            <div class="row">
                <div class="col-lg-7">
                    <div class="widget clearfix">
                        <img src="images/elybond/elybond_logo.png" width="150" class="img-fluid" alt="Elybond logo"
                            class="alignleft"
                            style="margin-top: 8px; padding-right: 18px; border-right: 1px solid #4A4A4A;">
                        <p class="mt-5">We source materials initially from other world renowned factories from Portugal,
                            Spain,
                            china, India, Italy and
                            other countries from middle East.
                        </p>

                    </div>
                </div>
                <div class="col-lg-5 mt-lg-0">
                    <div class="widget clearfix">
                    </div>
                    <div class="widget subscribe-widget clearfix">
                        <div class="row col-mb-30">
                            <div class="col-md-6 clearfix">
                                <a href="#" class="social-icon si-dark si-colored si-facebook mb-0"
                                    style="margin-right: 10px;">
                                    <i class="icon-facebook"></i>
                                    <i class="icon-facebook"></i>
                                </a>
                                <a href="#"><small style="display: block; margin-top: 3px;"><strong>Like
                                            us</strong><br>on Facebook</small></a>
                            </div>
                            <div class="col-md-6 clearfix">
                                <a href="#" class="social-icon si-dark si-colored si-rss mb-0"
                                    style="margin-right: 10px;">
                                    <i class="icon-instagram"></i>
                                    <i class="icon-instagram"></i>
                                </a>
                                <a href="#"><small
                                        style="display: block; margin-top: 3px;"><strong>Follow</strong><br>us on
                                        Instagram</small></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div id="copyrights">
        <div class="container">
            <div class="row justify-content-center col-mb-30">
                <div class="col-12 col-md-auto text-center text-md-start">
                    Copyrights © 2023 All Rights Reserved by Elybond International Limited.<br>
                </div>
            </div>
        </div>
    </div>
</footer>
</div>

<div id="gotoTop" class="icon-angle-up" style="display: none;"></div>

<script src="js/jquery.js"></script>
<script src="js/plugins.min.js"></script>

<script src="js/functions.js"></script>
<script defer=""
    src="https://static.cloudflareinsights.com/beacon.min.js/v652eace1692a40cfa3763df669d7439c1639079717194"
    integrity="sha512-Gi7xpJR8tSkrpF7aordPZQlW2DLtzUlZcumS8dMQjwDHEnw9I7ZLyiOj/6tZStRBGtGgN6ceN6cMH8z7etPGlw=="
    data-cf-beacon="{&quot;rayId&quot;:&quot;74f2858ebdf03ea6&quot;,&quot;token&quot;:&quot;0627f0b8b73941069bc19139e63db853&quot;,&quot;version&quot;:&quot;2022.8.1&quot;,&quot;si&quot;:100}"
    crossorigin="anonymous"></script>



</body>

</html>